import numpy as np

import sqlalchemy
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session
from sqlalchemy import create_engine, func, inspect

from flask import Flask, jsonify
import datetime as dt



engine = create_engine("sqlite:///Resources/hawaii.sqlite", connect_args={'check_same_thread': False}, echo=True)
Base = automap_base()
Base.prepare(engine, reflect=True)

Measurement = Base.classes.measurement
Station = Base.classes.station
session = Session(engine)

app = Flask(__name__)



@app.route("/")
def welcome():
    """List of Information on Honolulu Weather (api routes)."""
    return"""<html>
    <h1>List of Information on Honolulu Weather  (api routes)</h1>
    <ul>
    <br>
    <li>
    Daily precipitations from last year:
    <br>
    <a href="/api/v1.0/precipitation">/api/v1.0/precipitation</a>
    </li>
    <br>
    <li>
    Stations from the DataSet: 
    <br>
   <a href="/api/v1.0/stations">/api/v1.0/stations</a>
   </li>
    <br>
    <li>
    Temperature Observations from the previous year:
    <br>
    <a href="/api/v1.0/tobs">/api/v1.0/tobs</a>
    </li>
    <br>
    <li>
    Tmin, tmax, tavg for the dates greater than or equal to the date provided:
    <br>Replace end of url with format shown.
    <br>
    <a href="/api/v1.0/2017-03-08">/api/v1.0/2017-03-08</a>
    </li>
    <br>
    <li>
    Return a JSON list of tmin, tmax, tavg for the dates in range of start date and end date:
    <br>
    Replace end of url with format shown.
    <br>
    <a href="/api/v1.0/2017-02-01/2017-02-04">/api/v1.0/2017-02-01/2017-02-04</a>
    </li>
    <br>
    </ul>
    </html>

    """


@app.route("/api/v1.0/precipitation")
def precipitation():
    max_date = session.query(Measurement.date).order_by(Measurement.date.desc()).first()

    
    max_date = max_date[0]

    
    year_ago = dt.datetime.strptime(max_date, "%Y-%m-%d") - dt.timedelta(days=366)
    
    results_precip = session.query(Measurement.date, Measurement.prcp).filter(Measurement.date >= year_ago).all()

    precip_dict = dict(results_precip)

    return jsonify(precip_dict)

@app.route("/api/v1.0/stations")
def stations(): 
    results_stations =  session.query(Measurement.station).group_by(Measurement.station).all()

    stations_list = list(np.ravel(results_stations))

    return jsonify(stations_list)

@app.route("/api/v1.0/tobs")
def tobs(): 
    max_date = session.query(Measurement.date).order_by(Measurement.date.desc()).first()

    max_date = max_date[0]

    year_ago = dt.datetime.strptime(max_date, "%Y-%m-%d") - dt.timedelta(days=366)
    results_obs = session.query(Measurement.date, Measurement.tobs).filter(Measurement.date >= year_ago).all()

    obs_list = list(results_obs)

    return jsonify(obs_list)



@app.route("/api/v1.0/<start>")
def start(start=None):

    from_begin = session.query(Measurement.date, func.min(Measurement.tobs), func.avg(Measurement.tobs), func.max(Measurement.tobs)).filter(Measurement.date >= start).group_by(Measurement.date).all()
    from_begin_list=list(from_begin)
    return jsonify(from_begin_list)

    

@app.route("/api/v1.0/<start>/<end>")
def begin_end(start=None, end=None):

    beginend_dates = session.query(Measurement.date, func.min(Measurement.tobs), func.avg(Measurement.tobs), func.max(Measurement.tobs)).filter(Measurement.date >= start).filter(Measurement.date <= end).group_by(Measurement.date).all()
    beginend_dates_list=list(beginend_dates)
    return jsonify(beginend_dates_list)



if __name__ == '__main__':
    app.run(debug=True)